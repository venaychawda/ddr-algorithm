"""
confidence.py
-------------
Layer 4: Confidence score computation.

The confidence value (0–100) is not just a pass-through of the plausibility
vote score. It is a composite metric that accounts for:

  1. Plausibility vote agreement (base score)
  2. Speed magnitude (higher speed → more reliable wheel speed signals)
  3. Sensor fault count (fewer faults → higher confidence)
  4. FSM state (transition states get a confidence penalty)
  5. Time in current state (newly committed directions get a ramp-up)

Downstream consumers:
  - ESP: uses confidence to gate ESC intervention direction
  - HSA (Hill Start Assist): uses confidence + direction for hold direction
  - Park assist: uses confidence to validate reverse engagement

Clean-room implementation. Confidence model inspired by published literature
on multi-sensor fusion in automotive safety systems.
"""

from __future__ import annotations

from ddr_core.vehicle_signals import (
    WheelSpeeds, DiagnosticWord
)
from ddr_core.state_machine import FSMState


# ── Confidence contribution weights ───────────────────────────────────────────

W_VOTE_SCORE      = 0.50    # Plausibility vote agreement
W_SPEED           = 0.20    # Speed magnitude (higher = more reliable)
W_SENSOR_HEALTH   = 0.15    # Sensor fault status
W_TIME_IN_STATE   = 0.15    # Ramp-up for newly committed direction

# Speed at which wheel speed sensors are considered fully reliable (km/h)
SPEED_FULL_TRUST_KMH = 10.0

# Time to full confidence after entering a new stable state (ms)
RAMP_UP_TIME_MS = 500.0

# Confidence cap while in transition state
TRANSITION_CONFIDENCE_CAP = 35.0


class ConfidenceScorer:
    """
    Computes the final confidence score each DDR cycle.
    """

    def compute(
        self,
        vote_confidence: float,         # Raw 0–100 from plausibility aggregator
        mean_speed_kmh: float,
        processed_wheels: WheelSpeeds,
        fsm_state: FSMState,
        time_in_state_ms: float,
        transition_active: bool,
        diagnostics: DiagnosticWord,
    ) -> float:
        """
        Returns final confidence in range [0.0, 100.0].
        """

        # ── 1. Vote score component (normalised) ──────────────────────────────
        vote_component = (vote_confidence / 100.0) * 100.0

        # ── 2. Speed reliability component ────────────────────────────────────
        speed_component = min(100.0, (mean_speed_kmh / SPEED_FULL_TRUST_KMH) * 100.0)

        # ── 3. Sensor health component ────────────────────────────────────────
        # Count healthy sensors (OK or DEGRADED)
        statuses = [
            processed_wheels.fl_status, processed_wheels.fr_status,
            processed_wheels.rl_status, processed_wheels.rr_status,
        ]
        from ddr_core.vehicle_signals import SensorStatus
        healthy = sum(1 for s in statuses if s != SensorStatus.FAULT)
        health_component = (healthy / 4.0) * 100.0

        # ── 4. Time-in-state ramp-up ──────────────────────────────────────────
        ramp = min(1.0, time_in_state_ms / RAMP_UP_TIME_MS)
        ramp_component = ramp * 100.0

        # ── Weighted sum ──────────────────────────────────────────────────────
        raw = (
            W_VOTE_SCORE    * vote_component  +
            W_SPEED         * speed_component +
            W_SENSOR_HEALTH * health_component +
            W_TIME_IN_STATE * ramp_component
        )

        confidence = min(100.0, max(0.0, raw))

        # ── Penalty modifiers ─────────────────────────────────────────────────
        if transition_active:
            confidence = min(confidence, TRANSITION_CONFIDENCE_CAP)

        if diagnostics.gear_mismatch:
            confidence *= 0.85

        if diagnostics.plausibility_conflict:
            confidence *= 0.75

        if diagnostics.wheel_fault:
            confidence *= 0.90

        # Update diagnostics flag
        diagnostics.confidence_degraded = confidence < 70.0

        return round(min(100.0, max(0.0, confidence)), 1)
