"""
diagnostics.py
--------------
Layer 5: Diagnostic interface.

Every DDR output cycle emits a DiagnosticWord — a set of boolean flags
encoding the algorithm's internal health state. In a production ECU:
  - The diagnostic word would be encoded as a CAN signal (e.g. 8-bit bitmask)
  - CANoe DBC file would decode individual bits
  - A calibration engineer would log and monitor these during bench or vehicle test

This module also provides a human-readable diagnostic formatter
used by the CLI and Streamlit demo.

Clean-room implementation.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Iterator

from ddr_core.vehicle_signals import DiagnosticWord, DDROutput, DriveDirection


# Bitmask bit positions (for CAN encoding compatibility)
BIT_GEAR_MISMATCH        = 0
BIT_WHEEL_FAULT          = 1
BIT_LOW_SPEED_MODE       = 2
BIT_TRANSITION_ACTIVE    = 3
BIT_CONFIDENCE_DEGRADED  = 4
BIT_PLAUSIBILITY_CONFLICT = 5


def encode_diagnostic_word(diag: DiagnosticWord) -> int:
    """
    Encode DiagnosticWord to an 8-bit integer for CAN transmission.
    Bit layout matches BIT_* constants above.
    """
    word = 0
    if diag.gear_mismatch:         word |= (1 << BIT_GEAR_MISMATCH)
    if diag.wheel_fault:           word |= (1 << BIT_WHEEL_FAULT)
    if diag.low_speed_mode:        word |= (1 << BIT_LOW_SPEED_MODE)
    if diag.transition_active:     word |= (1 << BIT_TRANSITION_ACTIVE)
    if diag.confidence_degraded:   word |= (1 << BIT_CONFIDENCE_DEGRADED)
    if diag.plausibility_conflict: word |= (1 << BIT_PLAUSIBILITY_CONFLICT)
    return word


def decode_diagnostic_word(word: int) -> DiagnosticWord:
    """Decode an 8-bit integer back to DiagnosticWord (e.g. from CAN log)."""
    return DiagnosticWord(
        gear_mismatch        = bool(word & (1 << BIT_GEAR_MISMATCH)),
        wheel_fault          = bool(word & (1 << BIT_WHEEL_FAULT)),
        low_speed_mode       = bool(word & (1 << BIT_LOW_SPEED_MODE)),
        transition_active    = bool(word & (1 << BIT_TRANSITION_ACTIVE)),
        confidence_degraded  = bool(word & (1 << BIT_CONFIDENCE_DEGRADED)),
        plausibility_conflict= bool(word & (1 << BIT_PLAUSIBILITY_CONFLICT)),
    )


def format_diagnostic_summary(output: DDROutput) -> str:
    """
    Human-readable one-line diagnostic summary for CLI / logging.
    Example: [FORWARD 87%] gear_mismatch | low_speed_mode
    """
    diag = output.diagnostics
    active_flags = []
    if diag.gear_mismatch:         active_flags.append("gear_mismatch")
    if diag.wheel_fault:           active_flags.append("wheel_fault")
    if diag.low_speed_mode:        active_flags.append("low_speed_mode")
    if diag.transition_active:     active_flags.append("transition_active")
    if diag.confidence_degraded:   active_flags.append("confidence_degraded")
    if diag.plausibility_conflict: active_flags.append("plausibility_conflict")

    direction_str = output.direction.value
    flags_str = " | ".join(active_flags) if active_flags else "OK"
    return f"[{direction_str} {output.confidence:.0f}%] {flags_str}"


def iter_diagnostic_events(
    outputs: list[DDROutput],
) -> Iterator[tuple[float, str]]:
    """
    Iterate through a list of DDR outputs and yield (timestamp_ms, event_str)
    for any cycle where a new diagnostic flag becomes active.
    Useful for generating event logs from recorded drives.
    """
    prev_diag = DiagnosticWord()
    for out in outputs:
        d = out.diagnostics
        changes = []
        if d.gear_mismatch and not prev_diag.gear_mismatch:
            changes.append("GEAR_MISMATCH detected")
        if d.wheel_fault and not prev_diag.wheel_fault:
            changes.append("WHEEL_FAULT detected")
        if d.transition_active and not prev_diag.transition_active:
            changes.append(f"TRANSITION started → {out.direction.value}")
        if not d.transition_active and prev_diag.transition_active:
            changes.append(f"TRANSITION completed → {out.direction.value}")
        if d.plausibility_conflict and not prev_diag.plausibility_conflict:
            changes.append("PLAUSIBILITY_CONFLICT detected")
        for ch in changes:
            yield out.timestamp_ms, ch
        prev_diag = d


@dataclass
class SessionSummary:
    """Aggregate statistics for a complete recorded session."""
    total_cycles: int = 0
    forward_cycles: int = 0
    reverse_cycles: int = 0
    standstill_cycles: int = 0
    unknown_cycles: int = 0
    gear_mismatch_events: int = 0
    wheel_fault_events: int = 0
    transition_events: int = 0
    mean_confidence: float = 0.0
    min_confidence: float = 100.0

    @classmethod
    def from_outputs(cls, outputs: list[DDROutput]) -> "SessionSummary":
        s = cls()
        s.total_cycles = len(outputs)
        if not outputs:
            return s

        conf_sum = 0.0
        prev_diag = DiagnosticWord()

        for out in outputs:
            d = out.direction
            if d == DriveDirection.FORWARD:    s.forward_cycles += 1
            elif d == DriveDirection.REVERSE:  s.reverse_cycles += 1
            elif d == DriveDirection.STANDSTILL: s.standstill_cycles += 1
            else:                              s.unknown_cycles += 1

            if out.diagnostics.gear_mismatch and not prev_diag.gear_mismatch:
                s.gear_mismatch_events += 1
            if out.diagnostics.wheel_fault and not prev_diag.wheel_fault:
                s.wheel_fault_events += 1
            if out.diagnostics.transition_active and not prev_diag.transition_active:
                s.transition_events += 1

            conf_sum += out.confidence
            s.min_confidence = min(s.min_confidence, out.confidence)
            prev_diag = out.diagnostics

        s.mean_confidence = conf_sum / s.total_cycles
        return s

    def __str__(self) -> str:
        total = self.total_cycles or 1
        return (
            f"Session summary ({self.total_cycles} cycles)\n"
            f"  Forward:    {self.forward_cycles:5d} ({100*self.forward_cycles/total:.1f}%)\n"
            f"  Reverse:    {self.reverse_cycles:5d} ({100*self.reverse_cycles/total:.1f}%)\n"
            f"  Standstill: {self.standstill_cycles:5d} ({100*self.standstill_cycles/total:.1f}%)\n"
            f"  Unknown:    {self.unknown_cycles:5d} ({100*self.unknown_cycles/total:.1f}%)\n"
            f"  Confidence: mean={self.mean_confidence:.1f}%  min={self.min_confidence:.1f}%\n"
            f"  Events: gear_mismatch={self.gear_mismatch_events}  "
            f"wheel_fault={self.wheel_fault_events}  transitions={self.transition_events}"
        )
