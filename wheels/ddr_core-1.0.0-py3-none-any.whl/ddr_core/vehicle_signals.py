"""
vehicle_signals.py
------------------
Dataclass definitions for all DDR algorithm inputs and outputs.
Designed as a clean-room implementation based on standard automotive
signal processing literature and common VDC/ESP system interfaces.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional


class GearPosition(Enum):
    """Gear selector positions as reported by TCU via CAN."""
    PARK = "P"
    REVERSE = "R"
    NEUTRAL = "N"
    DRIVE = "D"
    UNKNOWN = "?"


class DriveDirection(Enum):
    """Output enum from DDR algorithm."""
    FORWARD = "FORWARD"
    REVERSE = "REVERSE"
    STANDSTILL = "STANDSTILL"
    UNKNOWN = "UNKNOWN"          # Transitioning or insufficient data


class SensorStatus(Enum):
    """Health status for each sensor input."""
    OK = auto()
    DEGRADED = auto()           # Signal noisy but usable
    FAULT = auto()              # Signal failed, excluded from fusion


@dataclass
class WheelSpeeds:
    """
    Four-corner wheel speed signals in km/h.
    Positive values only — sign of vehicle motion is inferred by DDR,
    not encoded in wheel speed sensors (they are magnitude-only).
    """
    fl: float = 0.0             # Front-left
    fr: float = 0.0             # Front-right
    rl: float = 0.0             # Rear-left
    rr: float = 0.0             # Rear-right

    # Per-sensor fault flags (set by signal_processor outlier rejection)
    fl_status: SensorStatus = SensorStatus.OK
    fr_status: SensorStatus = SensorStatus.OK
    rl_status: SensorStatus = SensorStatus.OK
    rr_status: SensorStatus = SensorStatus.OK

    def valid_speeds(self) -> list[float]:
        """Return only the speeds from sensors with OK or DEGRADED status."""
        pairs = [
            (self.fl, self.fl_status),
            (self.fr, self.fr_status),
            (self.rl, self.rl_status),
            (self.rr, self.rr_status),
        ]
        return [v for v, s in pairs if s != SensorStatus.FAULT]

    def mean_speed(self) -> float:
        valid = self.valid_speeds()
        return sum(valid) / len(valid) if valid else 0.0

    def any_fault(self) -> bool:
        return any(s == SensorStatus.FAULT for s in [
            self.fl_status, self.fr_status,
            self.rl_status, self.rr_status
        ])


@dataclass
class VehicleSignals:
    """
    Complete set of input signals consumed by the DDR algorithm
    at each 10ms cycle.
    """
    timestamp_ms: float                         # Milliseconds since epoch / session start
    wheel_speeds: WheelSpeeds = field(default_factory=WheelSpeeds)
    gear_position: GearPosition = GearPosition.UNKNOWN
    longitudinal_acceleration: float = 0.0      # m/s², positive = forward acceleration
    brake_pressure_bar: float = 0.0             # Master cylinder pressure, bar
    yaw_rate_deg_s: float = 0.0                 # deg/s, positive = left turn


@dataclass
class DiagnosticWord:
    """
    Bitmask-style diagnostic output emitted every DDR cycle.
    Used by calibration engineers on the bench and decoded by CANoe DBC.
    """
    gear_mismatch: bool = False          # Gear signal contradicts physical sensors
    wheel_fault: bool = False            # One or more wheel speed sensors flagged
    low_speed_mode: bool = False         # Vehicle below speed noise floor (~0.5 km/h)
    transition_active: bool = False      # FSM currently in a debounce transition
    confidence_degraded: bool = False    # Confidence below 70%
    plausibility_conflict: bool = False  # Multiple signals in disagreement

    def any_active(self) -> bool:
        return any([
            self.gear_mismatch, self.wheel_fault, self.low_speed_mode,
            self.transition_active, self.confidence_degraded,
            self.plausibility_conflict
        ])


@dataclass
class DDROutput:
    """
    Full output produced by DDR algorithm each cycle.
    Downstream consumers (ESP, HSA, park assist) use direction + confidence.
    """
    timestamp_ms: float
    direction: DriveDirection = DriveDirection.UNKNOWN
    confidence: float = 0.0             # 0.0 – 100.0
    diagnostics: DiagnosticWord = field(default_factory=DiagnosticWord)
    time_in_state_ms: float = 0.0       # How long we have been in current direction
    previous_direction: Optional[DriveDirection] = None
