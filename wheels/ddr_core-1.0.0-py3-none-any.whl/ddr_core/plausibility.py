"""
plausibility.py
---------------
Layer 2: Cross-signal plausibility engine.

Each check produces a PlausibilityVote with a direction suggestion and
a weight (confidence contribution). The engine aggregates votes to
determine the most physically credible direction and detect conflicts.

Key insight: wheel speed + acceleration are *physical* ground truth.
Gear signal is a CAN message that can be stale, delayed, or wrong
during a gear change. When they conflict, physical sensors win above
a configurable speed threshold.

Clean-room implementation based on published ESP/VDC literature.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from ddr_core.vehicle_signals import (
    VehicleSignals, WheelSpeeds, GearPosition,
    DriveDirection, DiagnosticWord
)


# ── Configuration ──────────────────────────────────────────────────────────────

# Speed at which wheel speed signal is trusted over gear signal (km/h)
SPEED_TRUST_THRESHOLD_KMH = 3.0

# Acceleration sign threshold — below this magnitude acc is considered noise
ACC_NOISE_FLOOR_MS2 = 0.15

# Speed noise floor — below this vehicle may or may not be moving
SPEED_NOISE_FLOOR_KMH = 0.5

# Brake pressure above which standstill is strongly suggested (bar)
BRAKE_STANDSTILL_THRESHOLD_BAR = 20.0


@dataclass
class PlausibilityVote:
    """A single cross-signal consistency check result."""
    source: str                         # E.g. "gear_vs_speed"
    suggested_direction: Optional[DriveDirection]
    weight: float                       # 0.0–1.0, contribution to confidence
    conflict: bool = False              # True if this check detected a conflict
    note: str = ""


class PlausibilityEngine:
    """
    Runs all plausibility checks and returns aggregated votes + diagnostic flags.
    """

    def evaluate(
        self,
        signals: VehicleSignals,
        processed_wheels: WheelSpeeds,
    ) -> tuple[list[PlausibilityVote], DiagnosticWord]:
        """
        Run all checks. Returns list of votes and diagnostic word.
        """
        diag = DiagnosticWord()
        votes: list[PlausibilityVote] = []

        mean_speed = processed_wheels.mean_speed()
        acc = signals.longitudinal_acceleration
        gear = signals.gear_position
        brake = signals.brake_pressure_bar

        # ── Check 1: Gear position signal ─────────────────────────────────────
        votes.append(self._check_gear(gear, mean_speed, diag))

        # ── Check 2: Longitudinal acceleration sign ───────────────────────────
        votes.append(self._check_acceleration(acc, mean_speed))

        # ── Check 3: Wheel speed magnitude (is vehicle moving?) ───────────────
        votes.append(self._check_speed_magnitude(mean_speed, brake, diag))

        # ── Check 4: Gear vs speed cross-check ───────────────────────────────
        votes.append(self._check_gear_speed_consistency(gear, mean_speed, acc, diag))

        # ── Check 4b: Neutral + negative acc + speed → rollback detection ─────
        votes.append(self._check_neutral_rollback(gear, acc, mean_speed))

        # ── Check 5: Wheel sensor fault status ───────────────────────────────
        if processed_wheels.any_fault():
            diag.wheel_fault = True

        # ── Check 6: Brake + acceleration plausibility ────────────────────────
        votes.append(self._check_brake_acc(brake, acc, mean_speed))

        # Detect overall conflict
        conflict_count = sum(1 for v in votes if v.conflict)
        if conflict_count >= 2:
            diag.plausibility_conflict = True

        return votes, diag

    # ── Individual checks ──────────────────────────────────────────────────────

    def _check_gear(
        self, gear: GearPosition, mean_speed: float, diag: DiagnosticWord
    ) -> PlausibilityVote:
        """Map gear position to a directional vote."""
        gear_map = {
            GearPosition.DRIVE:   DriveDirection.FORWARD,
            GearPosition.REVERSE: DriveDirection.REVERSE,
            GearPosition.PARK:    DriveDirection.STANDSTILL,
            GearPosition.NEUTRAL: None,
            GearPosition.UNKNOWN: None,
        }
        suggested = gear_map.get(gear)

        # Gear signal weight is reduced at low speed (more noise, slipping)
        # and reduced for NEUTRAL/UNKNOWN (non-directional information)
        if gear in (GearPosition.UNKNOWN, GearPosition.NEUTRAL):
            weight = 0.1
        elif mean_speed < SPEED_TRUST_THRESHOLD_KMH:
            weight = 0.6
        else:
            weight = 0.5   # Physical sensors get higher weight at speed

        return PlausibilityVote(
            source="gear_position",
            suggested_direction=suggested,
            weight=weight,
            note=f"gear={gear.value}"
        )

    def _check_acceleration(
        self, acc: float, mean_speed: float
    ) -> PlausibilityVote:
        """
        Longitudinal acceleration sign suggests direction only when above noise floor.
        Note: acc sign alone cannot distinguish forward from reverse — a braking
        vehicle going forward has negative acc. Use in combination with speed/gear.
        """
        if abs(acc) < ACC_NOISE_FLOOR_MS2:
            return PlausibilityVote(
                source="longitudinal_acc",
                suggested_direction=None,
                weight=0.05,
                note="acc in noise floor"
            )

        # Positive acc when moving = forward; negative = either braking fwd or accel rev
        if acc > 0:
            suggested = DriveDirection.FORWARD
            weight = 0.4
        else:
            # Negative acc is ambiguous — don't vote strongly
            suggested = None
            weight = 0.1

        return PlausibilityVote(
            source="longitudinal_acc",
            suggested_direction=suggested,
            weight=weight,
            note=f"acc={acc:.2f} m/s²"
        )

    def _check_speed_magnitude(
        self, mean_speed: float, brake: float, diag: DiagnosticWord
    ) -> PlausibilityVote:
        """
        Check whether the vehicle is in standstill territory.
        All-zero wheel speeds + high brake = confident STANDSTILL.
        """
        if mean_speed < SPEED_NOISE_FLOOR_KMH:
            diag.low_speed_mode = True
            if brake > BRAKE_STANDSTILL_THRESHOLD_BAR:
                return PlausibilityVote(
                    source="speed_magnitude",
                    suggested_direction=DriveDirection.STANDSTILL,
                    weight=0.95,
                    note="speed≈0 + brake applied → standstill"
                )
            else:
                return PlausibilityVote(
                    source="speed_magnitude",
                    suggested_direction=DriveDirection.STANDSTILL,
                    weight=0.55,
                    note="speed≈0, low brake → possible standstill"
                )
        return PlausibilityVote(
            source="speed_magnitude",
            suggested_direction=None,
            weight=0.1,
            note=f"speed={mean_speed:.1f} km/h, vehicle moving"
        )

    def _check_gear_speed_consistency(
        self,
        gear: GearPosition,
        mean_speed: float,
        acc: float,
        diag: DiagnosticWord,
    ) -> PlausibilityVote:
        """
        Cross-check gear signal against physical sensor evidence.
        If vehicle is clearly moving forward (speed>threshold, acc>0)
        but gear=R, flag a gear mismatch and trust the physical sensors.
        This is the most common real-world conflict — stale gear CAN message.
        """
        if mean_speed < SPEED_TRUST_THRESHOLD_KMH:
            return PlausibilityVote(
                source="gear_speed_cross",
                suggested_direction=None,
                weight=0.05,
                note="speed too low for cross-check"
            )

        # Physical evidence: vehicle clearly moving forward
        if acc > ACC_NOISE_FLOOR_MS2 and gear == GearPosition.REVERSE:
            diag.gear_mismatch = True
            return PlausibilityVote(
                source="gear_speed_cross",
                suggested_direction=DriveDirection.FORWARD,
                weight=0.85,
                conflict=True,
                note="gear=R contradicts speed+acc — trusting physical sensors"
            )

        return PlausibilityVote(
            source="gear_speed_cross",
            suggested_direction=None,
            weight=0.1,
            note="gear/speed consistent"
        )

    def _check_neutral_rollback(
        self, gear: GearPosition, acc: float, mean_speed: float
    ) -> PlausibilityVote:
        """
        Detect hill rollback in Neutral or Park.
        Signature: gear=N, acc < -threshold, speed > 0
        Wheel speed sensors are magnitude-only, so direction cannot come
        from wheel speed alone in neutral. Acceleration sign is the key signal.
        """
        if (
            gear in (GearPosition.NEUTRAL, GearPosition.PARK)
            and acc < -ACC_NOISE_FLOOR_MS2
            and mean_speed > SPEED_NOISE_FLOOR_KMH
        ):
            # Negative acc + moving + no gear engaged = rollback
            strength = min(0.80, 0.40 + abs(acc) * 0.10)
            return PlausibilityVote(
                source="neutral_rollback",
                suggested_direction=DriveDirection.REVERSE,
                weight=strength,
                note=f"gear=N, acc={acc:.2f} → rollback detected"
            )
        return PlausibilityVote(
            source="neutral_rollback",
            suggested_direction=None,
            weight=0.01,
            note="no rollback condition"
        )

    def _check_brake_acc(
        self, brake: float, acc: float, mean_speed: float
    ) -> PlausibilityVote:
        """
        High brake pressure + near-zero speed = strong standstill vote.
        """
        if brake > BRAKE_STANDSTILL_THRESHOLD_BAR and mean_speed < 2.0:
            return PlausibilityVote(
                source="brake_acc",
                suggested_direction=DriveDirection.STANDSTILL,
                weight=0.7,
                note=f"brake={brake:.0f} bar, speed≈0"
            )
        return PlausibilityVote(
            source="brake_acc",
            suggested_direction=None,
            weight=0.05,
            note="brake not deterministic"
        )


def aggregate_votes(
    votes: list[PlausibilityVote],
) -> tuple[DriveDirection, float]:
    """
    Weighted vote aggregation.
    Returns the winning direction and a raw confidence score (0–100).
    """
    scores: dict[DriveDirection, float] = {d: 0.0 for d in DriveDirection}
    total_weight = 0.0

    for vote in votes:
        if vote.suggested_direction is not None:
            scores[vote.suggested_direction] += vote.weight
        total_weight += vote.weight

    if total_weight == 0:
        return DriveDirection.UNKNOWN, 0.0

    # Winner = direction with highest weighted vote
    winner = max(scores, key=lambda d: scores[d])
    winner_score = scores[winner]

    # Normalise to 0–100 confidence
    confidence = min(100.0, (winner_score / total_weight) * 100.0 * 1.5)

    # If winning score is very low, output UNKNOWN
    if winner_score < 0.1:
        return DriveDirection.UNKNOWN, 0.0

    return winner, round(confidence, 1)
