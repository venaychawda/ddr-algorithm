# ddr_core — private implementation package
# Distributed as pre-compiled wheel. Source not included in public repo.
#
# vehicle_signals.py is bundled here so ddr_core is fully self-contained
# and has zero runtime dependency on ddr_algorithm.

from ddr_core.vehicle_signals import (
    VehicleSignals, WheelSpeeds, GearPosition,
    DriveDirection, DDROutput, DiagnosticWord,
    SensorStatus,
)
from ddr_core.signal_processor import SignalProcessor
from ddr_core.plausibility import PlausibilityEngine, aggregate_votes
from ddr_core.state_machine import DirectionStateMachine, FSMState
from ddr_core.confidence import ConfidenceScorer
from ddr_core.diagnostics import (
    format_diagnostic_summary,
    encode_diagnostic_word,
    decode_diagnostic_word,
    iter_diagnostic_events,
    SessionSummary,
)

__version__ = "1.0.0"
__all__ = [
    # Models (re-exported for convenience)
    "VehicleSignals", "WheelSpeeds", "GearPosition",
    "DriveDirection", "DDROutput", "DiagnosticWord", "SensorStatus",
    # Core layers
    "SignalProcessor",
    "PlausibilityEngine", "aggregate_votes",
    "DirectionStateMachine", "FSMState",
    "ConfidenceScorer",
    # Diagnostics utilities
    "format_diagnostic_summary",
    "encode_diagnostic_word", "decode_diagnostic_word",
    "iter_diagnostic_events",
    "SessionSummary",
]
