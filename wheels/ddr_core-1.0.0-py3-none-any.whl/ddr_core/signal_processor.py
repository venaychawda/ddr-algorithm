"""
signal_processor.py
-------------------
Layer 1: Raw signal pre-processing.

Responsibilities:
  - First-order IIR low-pass filtering of wheel speed signals
  - Outlier rejection: flags individual wheel sensors as FAULT
    when they deviate significantly from the peer group mean
  - Maintains rolling sensor health history for fault persistence
  - Operates at 10ms cycle time (100 Hz)

This is a clean-room implementation based on standard automotive
signal conditioning techniques described in SAE and AUTOSAR literature.
"""

from __future__ import annotations
from collections import deque
from typing import Deque
import math

from ddr_core.vehicle_signals import (
    VehicleSignals, WheelSpeeds, SensorStatus
)


# ── Configuration constants ────────────────────────────────────────────────────

# IIR filter coefficient: alpha=0.3 → ~33ms time constant at 100Hz
# Low alpha = more smoothing, higher latency
# High alpha = faster response, more noise
IIR_ALPHA = 0.3

# Wheel speed outlier threshold in km/h.
# If one wheel deviates from the mean of the other three by more than this,
# it is flagged as a potential fault.
OUTLIER_THRESHOLD_KMH = 8.0

# Number of consecutive fault samples before a sensor is declared FAULT.
# Prevents single-cycle noise spikes from triggering permanent fault.
FAULT_PERSISTENCE_CYCLES = 5

# Speed noise floor — below this, wheel speed sensors are unreliable
SPEED_NOISE_FLOOR_KMH = 0.5


class WheelSpeedFilter:
    """
    Per-wheel first-order IIR (exponential moving average) filter.
    y[n] = alpha * x[n] + (1 - alpha) * y[n-1]
    """

    def __init__(self, alpha: float = IIR_ALPHA):
        self._alpha = alpha
        self._state: float = 0.0
        self._initialised = False

    def update(self, raw: float) -> float:
        if not self._initialised:
            self._state = raw
            self._initialised = True
        else:
            self._state = self._alpha * raw + (1 - self._alpha) * self._state
        return self._state

    def reset(self):
        self._state = 0.0
        self._initialised = False


class SensorHealthTracker:
    """
    Tracks consecutive fault cycles for a single sensor.
    Declares FAULT only after FAULT_PERSISTENCE_CYCLES consecutive anomalies.
    Clears fault after the same number of clean cycles (hysteresis).
    """

    def __init__(self, persistence: int = FAULT_PERSISTENCE_CYCLES):
        self._persistence = persistence
        self._fault_count = 0
        self._clear_count = 0
        self.status = SensorStatus.OK

    def report(self, is_anomalous: bool):
        if is_anomalous:
            self._fault_count += 1
            self._clear_count = 0
            if self._fault_count >= self._persistence:
                self.status = SensorStatus.FAULT
        else:
            self._clear_count += 1
            self._fault_count = 0
            if self._clear_count >= self._persistence:
                self.status = SensorStatus.OK


class SignalProcessor:
    """
    Processes raw VehicleSignals each cycle.
    Returns a cleaned WheelSpeeds object with filtered values and fault flags.
    """

    def __init__(self):
        # One IIR filter per wheel
        self._filters = {
            'fl': WheelSpeedFilter(),
            'fr': WheelSpeedFilter(),
            'rl': WheelSpeedFilter(),
            'rr': WheelSpeedFilter(),
        }
        # One health tracker per wheel
        self._health = {
            'fl': SensorHealthTracker(),
            'fr': SensorHealthTracker(),
            'rl': SensorHealthTracker(),
            'rr': SensorHealthTracker(),
        }

    def process(self, signals: VehicleSignals) -> WheelSpeeds:
        """
        Main processing entry point. Call once per 10ms cycle.
        Returns filtered, fault-flagged WheelSpeeds.
        """
        ws = signals.wheel_speeds

        # Step 1: IIR filter raw values
        filtered = {
            'fl': self._filters['fl'].update(ws.fl),
            'fr': self._filters['fr'].update(ws.fr),
            'rl': self._filters['rl'].update(ws.rl),
            'rr': self._filters['rr'].update(ws.rr),
        }

        # Step 2: Outlier rejection — compare each wheel to mean of the other three
        wheels = ['fl', 'fr', 'rl', 'rr']
        for w in wheels:
            others = [filtered[o] for o in wheels if o != w]
            peer_mean = sum(others) / len(others)
            deviation = abs(filtered[w] - peer_mean)
            is_anomalous = deviation > OUTLIER_THRESHOLD_KMH
            self._health[w].report(is_anomalous)

        # Step 3: Build output WheelSpeeds with filtered values and status flags
        result = WheelSpeeds(
            fl=filtered['fl'], fr=filtered['fr'],
            rl=filtered['rl'], rr=filtered['rr'],
            fl_status=self._health['fl'].status,
            fr_status=self._health['fr'].status,
            rl_status=self._health['rl'].status,
            rr_status=self._health['rr'].status,
        )
        return result

    def reset(self):
        """Reset all filters and health trackers (e.g. ECU power cycle)."""
        for f in self._filters.values():
            f.reset()
        for h in self._health.values():
            h.__init__()
