"""
state_machine.py
----------------
Layer 3: Drive Direction Recognition finite-state machine.

States:
  FORWARD, REVERSE, STANDSTILL  — stable confirmed directions
  TRANSITIONING_FWD             — debouncing toward FORWARD
  TRANSITIONING_REV             — debouncing toward REVERSE

Hysteresis prevents chattering at the FORWARD↔STANDSTILL boundary,
which is the most common source of false DDR flips in parking scenarios.

The debounce timer (TRANSITION_DEBOUNCE_MS) holds the previous direction
for a configurable window before committing to a new direction. This is
the critical parameter that differs by vehicle type and application.

Clean-room implementation based on standard FSM patterns in automotive
safety-critical software (see AUTOSAR SWS_StateManager, SAE J2168).
"""

from __future__ import annotations
from enum import Enum, auto

from ddr_core.vehicle_signals import DriveDirection


# ── Configuration ──────────────────────────────────────────────────────────────

# How long to hold the previous direction before committing to a new one.
# 200ms is typical for passenger vehicles. Reduce for sports/performance.
TRANSITION_DEBOUNCE_MS = 200.0

# Minimum speed for FORWARD/REVERSE states — below this, FSM considers standstill
STANDSTILL_SPEED_KMH = 0.5

# How many consecutive cycles the plausibility engine must agree on a
# new direction before the FSM initiates a transition
DIRECTION_AGREE_CYCLES = 3


class FSMState(Enum):
    """Internal FSM states — superset of DriveDirection."""
    FORWARD = auto()
    REVERSE = auto()
    STANDSTILL = auto()
    TRANSITIONING_FWD = auto()
    TRANSITIONING_REV = auto()
    INIT = auto()               # First cycle, no history


# Map FSM state to output DriveDirection
_STATE_TO_DIRECTION = {
    FSMState.FORWARD:           DriveDirection.FORWARD,
    FSMState.REVERSE:           DriveDirection.REVERSE,
    FSMState.STANDSTILL:        DriveDirection.STANDSTILL,
    FSMState.TRANSITIONING_FWD: DriveDirection.UNKNOWN,   # Hold until debounce expires
    FSMState.TRANSITIONING_REV: DriveDirection.UNKNOWN,
    FSMState.INIT:              DriveDirection.UNKNOWN,
}


class DirectionStateMachine:
    """
    FSM that converts plausibility engine output into a stable DDR output.
    Maintains state across cycles.
    """

    def __init__(
        self,
        debounce_ms: float = TRANSITION_DEBOUNCE_MS,
        agree_cycles: int = DIRECTION_AGREE_CYCLES,
    ):
        self._state = FSMState.INIT
        self._debounce_ms = debounce_ms
        self._agree_cycles = agree_cycles

        self._time_in_state_ms: float = 0.0
        self._consecutive_agree: int = 0
        self._last_stable_direction = DriveDirection.UNKNOWN
        self._pending_direction: DriveDirection | None = None

    @property
    def current_state(self) -> FSMState:
        return self._state

    @property
    def time_in_state_ms(self) -> float:
        return self._time_in_state_ms

    def update(
        self,
        proposed_direction: DriveDirection,
        confidence: float,
        dt_ms: float = 10.0,
    ) -> tuple[DriveDirection, bool]:
        """
        Advance the FSM by one cycle.

        Args:
            proposed_direction: Output from plausibility engine vote aggregation
            confidence:         0–100 confidence in proposed direction
            dt_ms:              Cycle time in milliseconds (default 10ms = 100Hz)

        Returns:
            (output_direction, transition_active)
        """
        self._time_in_state_ms += dt_ms

        # ── INIT: Accept first confident direction immediately ─────────────────
        if self._state == FSMState.INIT:
            if proposed_direction != DriveDirection.UNKNOWN and confidence > 40.0:
                self._enter_state(self._direction_to_state(proposed_direction))
            return _STATE_TO_DIRECTION[self._state], False

        # ── Track consecutive agreement with proposed direction ───────────────
        current_output = _STATE_TO_DIRECTION[self._state]
        if proposed_direction == current_output:
            self._consecutive_agree = min(self._consecutive_agree + 1, 99)
            self._pending_direction = None
        else:
            if proposed_direction == self._pending_direction:
                self._consecutive_agree += 1
            else:
                # New proposed direction — reset counter
                self._consecutive_agree = 1
                self._pending_direction = proposed_direction

        # ── STABLE STATES: check if we should start transitioning ─────────────
        if self._state in (FSMState.FORWARD, FSMState.REVERSE, FSMState.STANDSTILL):
            if (
                self._pending_direction is not None
                and self._consecutive_agree >= self._agree_cycles
                and proposed_direction != current_output
            ):
                self._start_transition(proposed_direction)
                return _STATE_TO_DIRECTION[self._state], True

            return _STATE_TO_DIRECTION[self._state], False

        # ── TRANSITIONING STATES: check if debounce has expired ───────────────
        if self._state in (FSMState.TRANSITIONING_FWD, FSMState.TRANSITIONING_REV):
            if self._time_in_state_ms >= self._debounce_ms:
                # Commit to the pending direction
                target = self._pending_direction or proposed_direction
                self._enter_state(self._direction_to_state(target))
                self._last_stable_direction = _STATE_TO_DIRECTION[self._state]
                self._pending_direction = None
                return _STATE_TO_DIRECTION[self._state], False
            else:
                # Still in debounce window — output UNKNOWN
                return DriveDirection.UNKNOWN, True

        return DriveDirection.UNKNOWN, False

    def reset(self):
        """Reset FSM to initial state (ECU restart / ignition cycle)."""
        self._state = FSMState.INIT
        self._time_in_state_ms = 0.0
        self._consecutive_agree = 0
        self._last_stable_direction = DriveDirection.UNKNOWN
        self._pending_direction = None

    # ── Private helpers ────────────────────────────────────────────────────────

    def _enter_state(self, new_state: FSMState):
        self._state = new_state
        self._time_in_state_ms = 0.0
        self._consecutive_agree = 0

    def _start_transition(self, target: DriveDirection):
        if target == DriveDirection.FORWARD:
            self._enter_state(FSMState.TRANSITIONING_FWD)
        elif target == DriveDirection.REVERSE:
            self._enter_state(FSMState.TRANSITIONING_REV)
        else:
            # Standstill transition is immediate (no debounce needed)
            self._enter_state(FSMState.STANDSTILL)
        self._pending_direction = target

    @staticmethod
    def _direction_to_state(direction: DriveDirection) -> FSMState:
        return {
            DriveDirection.FORWARD:    FSMState.FORWARD,
            DriveDirection.REVERSE:    FSMState.REVERSE,
            DriveDirection.STANDSTILL: FSMState.STANDSTILL,
            DriveDirection.UNKNOWN:    FSMState.INIT,
        }.get(direction, FSMState.INIT)
